# Project

## Introduction
Something idk

## Features
- There is no feature right now :v

## Usage
Just download the code and open with live server

## Changelog
- 01/02/2025: 
+ Thay đổi cấu trúc từ Statistics sang Schedule
+ Fix lại tổng quan dashboard
* Những vấn đề còn tồn đọng:
+ Chưa dồng bộ với admin
+ Dư chức năng không sử dụng tới
+ LocalStorage không get được teacherName
